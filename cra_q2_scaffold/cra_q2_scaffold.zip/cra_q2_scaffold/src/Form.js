import React from 'react'

const Form = () => {
  return (
    
      <div>
       <form>{/* Create a h3, 2 inputs and 1 button here */}
        <h3> Login Page  </h3>
        <input placeholder ="YourName"/> 
        <input type="email" placeholder="xyz@pqr.com"/> 
       <button> Submit </button>
        </form>
       </div>
    
  )
}

export default Form