import React from 'react'

function App() {
  return (
    <div>"Welcome to React Course on codingninjas.com"</div>
  )
}

export default App
 